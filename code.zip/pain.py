import numpy as np
import pandas as pd

from sklearn.decomposition import PCA
np.random.seed(1337)  # for reproducibility
import keras
from sklearn.metrics import average_precision_score
from keras import initializers,layers,regularizers
from keras.layers import Dropout
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from scipy import interp
from tensorflow.keras import layers, models, initializers
from tensorflow.keras.layers import BatchNormalization
import tensorflow.keras.backend as K
from keras import backend as K
import tensorflow as tf
from tensorflow.keras.layers import Layer, Dense, Dropout, LayerNormalization
from sklearn.metrics import roc_auc_score, auc, precision_recall_curve, roc_curve
import numpy as np
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

def pca(file_name,n_componets=64):
    data = pd.read_csv(file_name, header=None, delimiter=",")
    pca = PCA(n_components=n_componets)
    data_pca = pca.fit_transform(data)
    return data_pca

neg_samples = pd.read_csv('data/negative_example.csv',header=None)
pos_samples = pd.read_csv("data/positive_example.csv",header=None)
drug_features = pca('data/Drugmat.csv',n_componets=128)
microbe_features =pca("data/Microbemat.csv",n_componets=64)

num_neg_samples_per_cv = int(1152)

def get_neg_samples_for_cv(neg_samples, num_neg_samples_per_cv):
    return neg_samples.sample(n=num_neg_samples_per_cv)

def get_features(items,features):
    l = []
    for item in items:
        l.append(features[item-1,:])
    return l

neg_samples_for_cv = get_neg_samples_for_cv(neg_samples, num_neg_samples_per_cv)
merged_samples = pd.concat([pos_samples,neg_samples_for_cv])
merged_samples = merged_samples.values
# 获取药物和微生物标签
drug_item1 = merged_samples[:,0]
print(drug_item1)
microbe_item2 = merged_samples[:,1]
# 获取关联标签
label = merged_samples[:,2]
label = np.array(label)

# 通过药物和微生物索引获得药物和微生物的特征
drug = get_features(drug_item1,drug_features)
drug = np.array(drug)
microbe = get_features(microbe_item2,microbe_features)
microbe = np.array(microbe)

merged_matrix = np.hstack((drug, microbe))
print(merged_matrix.shape)
print(label.shape)
X_train, X_test, Y_train, Y_test = train_test_split(merged_matrix, label, test_size=0.2, random_state=0)
X_all = np.concatenate((X_train,X_test))
Y_all = np.concatenate((Y_train,Y_test))
print(X_all.shape)
print(Y_all.shape)


SampleFeature_original = merged_matrix
SampleLabel_original=label
sample_label=[]
for i in range(len(SampleLabel_original)):
    if SampleLabel_original[i]==1:
        sample_label.append([0,1])
    else:
        sample_label.append([1,0])
sample_label=np.asarray(sample_label)
print(sample_label)


sample_data_old=merged_matrix.reshape(num_neg_samples_per_cv+1152,3,64)
sample_data=sample_data_old.transpose((0,2,1))
sample_data=np.expand_dims(sample_data,axis=2)

class Length(layers.Layer):
    def call(self, inputs, **kwargs):
        return K.sqrt(K.sum(K.square(inputs), -1))
    def compute_output_shape(self, input_shape):
        return input_shape[:-1]

def squash(vectors, axis=-1):
    s_squared_norm = K.sum(K.square(vectors), axis, keepdims=True)
    scale = s_squared_norm / (1 + s_squared_norm) / K.sqrt(s_squared_norm + K.epsilon())
    return scale * vectors

class CapsuleLayer(layers.Layer):
    def __init__(self, num_capsule, dim_vector, num_routing=3,
                 kernel_initializer='glorot_uniform',
                 bias_initializer='zeros',
                 **kwargs):
        super(CapsuleLayer, self).__init__(**kwargs)
        self.num_capsule = num_capsule
        self.dim_vector = dim_vector
        self.num_routing = num_routing
        self.kernel_initializer = initializers.get(kernel_initializer)
        self.bias_initializer = initializers.get(bias_initializer)


    def build(self, input_shape):
        print(f"Input_shape{input_shape}")
        assert len(input_shape) >= 3, "The input Tensor should have shape=[None, input_num_capsule, input_dim_vector]"
        self.input_num_capsule = 832
        self.input_dim_vector = input_shape[2]
        self.W = self.add_weight(
            shape=[self.input_num_capsule, self.num_capsule, self.input_dim_vector, self.dim_vector],
            initializer=self.kernel_initializer,
            name='W')
        print("the weight size in capsule layer", self.W)
        self.bias = self.add_weight(shape=[1, self.input_num_capsule, self.num_capsule, 1, 1],
                                    initializer=self.bias_initializer,
                                    name='bias',
                                    trainable=False)
        self.built = True
    def call(self, inputs, training=None):
        inputs_expand = K.expand_dims(K.expand_dims(inputs, 2), 2)
        inputs_tiled = K.tile(inputs_expand, [1, 1, self.num_capsule, 1, 1])
        inputs_hat = tf.scan(lambda ac, x: K.batch_dot(x, self.W, [3, 2]),
                             elems=inputs_tiled,
                             initializer=K.zeros([self.input_num_capsule, self.num_capsule, 1, self.dim_vector]))
        assert self.num_routing > 0, 'The num_routing should be > 0.'
        for i in range(self.num_routing):
            c = tf.nn.softmax(self.bias, dim=2)
            outputs = squash(K.sum(c * inputs_hat, 1, keepdims=True))
            if i != self.num_routing - 1:
                self.bias.assign_add(K.sum(inputs_hat * outputs, axis=-1, keepdims=True))
        return K.reshape(outputs, [-1, self.num_capsule, self.dim_vector])

    def compute_output_shape(self, input_shape):
        return tuple([None, self.num_capsule, self.dim_vector])

    def get_config(self):
        config = super().get_config()
        config.update({
            'num_capsule': self.num_capsule,
            'dim_vector': self.dim_vector,
            'num_routing': self.num_routing,
            'kernel_initializer': initializers.serialize(self.kernel_initializer),
            'bias_initializer': initializers.serialize(self.bias_initializer),
        })
        return config

    @classmethod
    def from_config(cls, config):
        config['kernel_initializer'] = initializers.deserialize(config['kernel_initializer'])
        config['bias_initializer'] = initializers.deserialize(config['bias_initializer'])
        return cls(**config)
def PrimaryCap(inputs, dim_vector, n_channels, kernel_size, strides, padding):
    output = layers.Conv1D(filters=dim_vector * n_channels, kernel_size=kernel_size, strides=strides, padding=padding,name='PrimaryCaps_conv1d')(inputs)
    output=BatchNormalization()(output)
    output=Dropout(0.2)(output)
    outputs = layers.Reshape(target_shape=[-1, dim_vector], name='PrimaryCaps_reshape')(output)
    return layers.Lambda(squash, name='PrimaryCaps_squash')(outputs)

def new(input):
    return tf.expand_dims(input,-1)

class MultiHeadAttention(Layer):
    def __init__(self, embed_dim, num_heads, **kwargs):
        super(MultiHeadAttention, self).__init__(**kwargs)
        self.num_heads = num_heads
        self.embed_dim = embed_dim

        assert embed_dim % self.num_heads == 0

        self.depth = embed_dim // self.num_heads

        self.Wq = Dense(embed_dim)
        self.Wk = Dense(embed_dim)
        self.Wv = Dense(embed_dim)

        self.dense = Dense(embed_dim)

    def split_heads(self, x, batch_size):
        x = tf.reshape(x, (batch_size, -1, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])

    def call(self, inputs):
        batch_size = tf.shape(inputs)[0]

        q = self.Wq(inputs)
        k = self.Wk(inputs)
        v = self.Wv(inputs)

        q = self.split_heads(q, batch_size)
        k = self.split_heads(k, batch_size)
        v = self.split_heads(v, batch_size)

        matmul_qk = tf.matmul(q, k, transpose_b=True)
        dk = tf.cast(tf.shape(k)[-1], tf.float32)
        scaled_attention_logits = matmul_qk / tf.math.sqrt(dk)

        weights = tf.nn.softmax(scaled_attention_logits, axis=-1)

        output = tf.matmul(weights, v)

        output = tf.transpose(output, perm=[0, 2, 1, 3])
        concat_output = tf.reshape(output, (batch_size, -1, self.embed_dim))

        return self.dense(concat_output)

    def get_config(self):
        config = super(MultiHeadAttention, self).get_config()
        config.update({
            'num_heads': self.num_heads,
            'embed_dim': self.embed_dim
        })
        return config

    @classmethod
    def from_config(cls, config):
        return cls(**config)

def TransformerEncoderBlock(inputs, embed_dim, num_heads, ff_dim, rate=0.2):
    attention_output = MultiHeadAttention(embed_dim, num_heads)(inputs)
    attention_output = Dropout(rate)(attention_output)
    attention_output = LayerNormalization(epsilon=1e-6)(inputs + attention_output)

    ff_output = Dense(ff_dim, activation='relu')(attention_output)
    ff_output = Dense(embed_dim)(ff_output)
    ff_output = Dropout(rate)(ff_output)
    output = LayerNormalization(epsilon=1e-6)(attention_output + ff_output)
    return output

def CapsNet(input_shape, n_class, num_routing):

    x = layers.Input(shape=input_shape)
    temp = layers.GlobalAveragePooling2D()(x)
    temp = layers.Dense(int(x.shape[-1]) * 5, use_bias=False,activation=keras.activations.relu)(temp)
    temp = layers.Dense(int(x.shape[-1]), use_bias=False,activation=keras.activations.hard_sigmoid)(temp)
    att = layers.Multiply()([temp,x])
    after_att = layers.Reshape(target_shape=[64,3], name='after_attention')(att)
    conv1 = layers.Conv1D(filters=64, kernel_size=9, strides=1, padding='valid', activation='relu', name='Conv1D')(after_att)
    conv1=BatchNormalization()(conv1)
    conv1=Dropout(0.2)(conv1)
    # Transformer
    embed_dim = 64  # 嵌入的维度
    num_heads = 32   # 注意力头的数量
    ff_dim = 64  # 前馈网络的维度
    transformer_block = TransformerEncoderBlock(conv1, embed_dim, num_heads, ff_dim)
    primarycaps = PrimaryCap(transformer_block, dim_vector=16, n_channels=16, kernel_size=5, strides=1, padding='valid')
    digitCaps = CapsuleLayer(num_capsule=n_class, dim_vector=16, num_routing=num_routing, name='DigitCaps')(primarycaps)
    out = Length(name='CapsNet')(digitCaps)
    train_model = models.Model(x, out)
    return train_model

def margin_loss(y_true, y_pred):
    y_true = tf.cast(y_true, tf.float32)
    L = y_true * K.square(K.maximum(0., 0.9 - y_pred)) + \
        0.5 * (1 - y_true) * K.square(K.maximum(0., y_pred - 0.1))
    return K.mean(K.sum(L, 1))

kf = KFold(n_splits=5, shuffle=True)

tprs = []
mean_fpr = np.linspace(0, 1, 100)
y_real = []
y_proba = []
AverageResult = []
global_recall = np.linspace(0, 1, 1000)
mean_precision = np.zeros_like(global_recall)
def get_dataset(x, y, batch_size=32, shuffle=False):
    dataset = tf.data.Dataset.from_tensor_slices((x, y))
    if shuffle:
        dataset = dataset.shuffle(buffer_size=len(x))
    dataset = dataset.batch(batch_size, drop_remainder=True)
    return dataset

fig, ax = plt.subplots(1, 2, figsize=(12, 6))
for i, (train_index, test_index) in enumerate(kf.split(sample_data)):
    x_train, x_test = sample_data[train_index], sample_data[test_index]
    y_train, y_test = sample_label[train_index], sample_label[test_index]
    temp1 = len(x_train)
    temp2 = int(0.8 * temp1)
    x_train_new, y_train_new = x_train[:temp2], y_train[:temp2]
    x_valid, y_valid = x_train[temp2:], y_train[temp2:]
    train_dataset = get_dataset(x_train_new, y_train_new, batch_size=128, shuffle=True)
    valid_dataset = get_dataset(x_valid, y_valid, batch_size=128,shuffle=True)
    test_dataset = get_dataset(x_test, y_test, batch_size=128,shuffle=True)
    print(x_train_new.shape)
    print(y_train_new.shape)
    print(x_valid.shape)
    print(y_valid.shape)
    print(x_test.shape)
    print(y_test.shape)
    model = CapsNet(input_shape=(64, 1, 3), n_class=2, num_routing=5)
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),
                  loss=margin_loss,
                  metrics=['acc'])
    call = [tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=5)]
    model.fit(train_dataset, epochs=100, validation_data=valid_dataset, callbacks=call)
    batch_size = 128
    num_full_batches = len(x_test) // batch_size
    new_size = num_full_batches * batch_size
    x_test_trimmed = x_test[:new_size]
    y_test_pred = model.predict(x_test_trimmed, batch_size=batch_size)
    y_test_adjusted = y_test[:len(y_test_pred)]
    y_pred_prob = y_test_pred[:, 1]
    y_true = y_test_adjusted[:, 1]
    print(f"y_test_adjusted:{y_true},{len(y_true)}")
    print(f"y_test_pred:{y_pred_prob},{len(y_pred_prob)}")
    auc_score = roc_auc_score(y_true, y_pred_prob)
    print("AUC Score:", auc_score)
    aupr_score = average_precision_score(y_true, y_pred_prob)
    print("AUPR Score:", aupr_score)
    fpr, tpr, _ = roc_curve(y_true, y_pred_prob)
    roc_auc = auc(fpr, tpr)
    tprs.append(interp(mean_fpr,fpr,tpr))
    tprs[-1][0] = 0.0
    ax[0].plot(fpr, tpr, lw=1, alpha=0.3, label='ROC fold %d (AUC = %0.4f)' % (i+1, roc_auc))
    precision,recall,_ = precision_recall_curve(y_true,y_pred_prob)
    mean_precision += np.interp(global_recall, recall[::-1], precision[::-1])
    y_real.append(y_true)
    y_proba.append(y_pred_prob)
    ax[1].plot(recall, precision, lw=1, alpha=0.3, label='PR fold %d (AUPR = %0.4f)' % (i+1, aupr_score))
# 对ROC曲线求平均并绘制
mean_tpr = np.mean(tprs, axis=0)
mean_tpr[-1] = 1.0
mean_auc = auc(mean_fpr, mean_tpr)
std_auc = np.std([auc(mean_fpr, t) for t in tprs])
ax[0].plot(mean_fpr, mean_tpr, color='b', label=r'Mean ROC (AUC = %0.4f $\pm$ %0.02f)' % (mean_auc, std_auc), lw=2, alpha=0.8)
mean_precision /= len(y_real)
mean_aupr = auc(global_recall, mean_precision)
ax[1].plot(global_recall,mean_precision,color="r",label="Mean PR (AUPR = {:.4f} $\pm$ 0.02)".format(mean_aupr))
# 设置图例和标签
ax[0].set(xlim=[-0.05, 1.05], ylim=[-0.05, 1.05], title="Receiver Operating Characteristic")
ax[0].legend(loc="lower right")
ax[1].set(xlim=[-0.05, 1.05], ylim=[-0.05, 1.05], title="Precision-Recall Curve")
ax[1].legend(loc="lower left")
print(f"mean_auc:{mean_auc}")
print(f"mean_aupr{mean_aupr}")
plt.show()

















